Spring boot microservice - Category
